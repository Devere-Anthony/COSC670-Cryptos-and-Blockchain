# Assignment 0

Hello 👋🏾, thanks for checking out my assignment 0 submission. 

Some of the code in the project relies on third party NPM packages.
To build the project with the above dependencies simply run `npm install` in the top level directory where the `package.json` file resides. 

This should install the dependencies needed for the project. Optionally you can install Axios and Dotenv via the `npm install axios` and `npm install dotenv` commands. 

Once the dependencies are installed, you **must** use your Etherscan API key for a few of the scripts to run properly. To do so:
1. Open the `.env` file in the top level directory.
2. Replace the commented out section with your Etherscan API key. 
3. Save this file.

The requests to the Etherscan API should work now without any problems. All the scripts can be run directly on the command-line by running `node <filename.js>`. 